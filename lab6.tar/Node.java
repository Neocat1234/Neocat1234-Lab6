public class Node {
    public Thing data;
    public Node next;

    public Node(Thing data) {
        this.data = data;
        this.next = null;
    }
}